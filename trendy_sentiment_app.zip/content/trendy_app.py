from flask import Flask, render_template, jsonify
import requests
from bs4 import BeautifulSoup
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download("vader_lexicon")

app = Flask(__name__, template_folder='/content/templates', static_folder='/content/static')
sia = SentimentIntensityAnalyzer()

def fetch_hot_topics():
    url = "https://trends.google.com/trends/trendingsearches/daily?geo=IN"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        return ["Data Fetch Error"]

    soup = BeautifulSoup(response.text, "html.parser")
    trends = soup.find_all("div", class_="title")[:10]
    return [trend.text.strip() for trend in trends]

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/api/trendy')
def trendy_data():
    hot_topics = fetch_hot_topics()
    sentiments = {topic: sia.polarity_scores(topic)["compound"] for topic in hot_topics}
    return jsonify({"trending_topics": hot_topics, "sentiment_scores": sentiments})

if __name__ == "__main__":
    app.run(debug=True)
